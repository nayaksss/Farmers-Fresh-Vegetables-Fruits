//
//  CarTableViewCell.swift
//  GFresh1
//
//  Created by Vinayak Balaji Tuptewar on 18/08/20.
//  Copyright © 2020 Vinayak Balaji Tuptewar. All rights reserved.
//

import UIKit

class CarTableViewCell: UITableViewCell {
    @IBOutlet weak var imagev: UIImageView!
    @IBOutlet weak var namelbl: UILabel!
    @IBOutlet weak var qtylbl: UILabel!
    @IBOutlet weak var rslbl: UILabel!
    @IBOutlet weak var mrplbl: UILabel!
    
    @IBOutlet weak var qtyBtn: UIButton!
    @IBOutlet weak var minuspluslbl: UILabel!
    
    @IBOutlet weak var plusbtn: UIButton!
    
    @IBOutlet weak var minusbtn: UIButton!
    
    @IBOutlet weak var contentViews: UIView!
    @IBOutlet weak var backViews: UIView!
    
    @IBOutlet weak var outerViews: UIView!
    
//    @IBOutlet weak var stackViews: UIStackView!
   
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.outerViews.layer.borderWidth = 2
        self.outerViews.layer.borderColor = UIColor.systemYellow.cgColor
        
        
        
        self.backViews.layer.shadowColor = UIColor.orange.cgColor
//        self.backViews.layer.shadowOffset = CGSize(width: 0, height: 0)
//        self.backViews.layer.shadowRadius = 10
        self.backViews.layer.shadowOpacity = 0.8
        self.backViews.layer.masksToBounds = false
//        self.backViews.layer.shadowPath = self.backViews.layer.bounds as! CGPath
        
        

//
        self.backViews.layer.borderWidth = 1.0
        self.backViews.layer.cornerRadius = 10.0
        
        self.backViews.layer.borderColor = UIColor.clear.cgColor
//        self.backViews.layer.masksToBounds = true
        
        self.backViews.layer.shadowOpacity = 0.4
        self.backViews.layer.shadowOffset = CGSize(width: 0, height: 4)
        self.backViews.layer.shadowRadius = 4.0
        self.backViews.layer.shadowColor = UIColor.lightGray.cgColor
//        self.backViews.layer.masksToBounds = false
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

       
    }

}
