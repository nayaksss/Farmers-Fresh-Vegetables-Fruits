//
//  OrderPlacedCollectionViewCell.swift
//  GFresh1
//
//  Created by Vinayak Balaji Tuptewar on 18/08/20.
//  Copyright © 2020 Vinayak Balaji Tuptewar. All rights reserved.
//
import UIKit

class newhomeTableViewCell: UITableViewCell {

    @IBOutlet weak var lbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
