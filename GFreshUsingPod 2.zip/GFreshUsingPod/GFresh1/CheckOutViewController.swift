//
//  CheckOutViewController.swift
//  GFresh1
//
//  Created by Vinayak Balaji Tuptewar on 18/08/20.
//  Copyright © 2020 Vinayak Balaji Tuptewar. All rights reserved.
//chnage

import UIKit

class CheckOutViewController: UIViewController {
    @IBOutlet weak var collectionView: UICollectionView!
    var arrData = [TempAddedArray]()
    @IBOutlet weak var noOfItemsLbl: UILabel!
    @IBOutlet weak var totalLbl: UILabel!
    @IBOutlet weak var orderTotalLbl: UILabel!
    
    @IBOutlet weak var paymentInfoView: UIView!
    @IBOutlet weak var ordersummaryView: UIView!
    
    @IBOutlet weak var viewBelowScrollV: UIView!
    @IBOutlet weak var scrollview: UIScrollView!
    @IBOutlet weak var viewAboveScrollV: UIView!
    
    @IBOutlet weak var confirmButton: UIButton!
   
    var valuess  = 0
    var totalItems = Int()
    var totalAmount = Double()
    var totalWithDelivery = Double()
    
    override func viewDidLoad() {
        super.viewDidLoad()
      
        scrollview.bounces = false
        //self.navigationItem.leftBarButtonItem?.title = "Check Out"
        
//        let leftItem = UIBarButtonItem(title: "Check Out",
//                                       style: UIBarButtonItem.Style.plain,
//                                       target: nil,
//                                       action: nil)
//        leftItem.isEnabled = false
//
//        self.navigationItem.leftBarButtonItem = leftItem
//        
        //self.navigationItem.title = "Check Out"
        
        confirmButton.layer.cornerRadius = 15.0
        
        self.viewBelowScrollV.layer.shadowOpacity = 0.4
        self.viewBelowScrollV.layer.shadowOffset = CGSize(width: 0, height: 3)
        self.viewBelowScrollV.layer.shadowRadius = 6.0
        self.viewBelowScrollV.layer.shadowColor = UIColor.lightGray.cgColor
        
//        self.MainView.layer.borderWidth = 1.0
//        self.MainView.layer.cornerRadius = 0
//        self.MainView.layer.borderColor = UIColor.clear.cgColor
//        self.MainView.layer.masksToBounds = true
//        self.MainView.layer.shadowOpacity = 0.7
//        self.MainView.layer.shadowOffset = CGSize(width: 0, height: 0)
//        self.MainView.layer.shadowRadius = 4.0
//        self.MainView.layer.shadowColor = UIColor.lightGray.cgColor
//        self.MainView.layer.masksToBounds = false

        
        
        self.navigationController?.navigationBar.tintColor = .white
        paymentInfoView.layer.borderWidth = 1
        paymentInfoView.layer.borderColor = UIColor.black.cgColor
        
//      MainView.layer.borderWidth = 10
//      MainView.layer.borderColor = UIColor.black.cgColor
    
       ordersummaryView.layer.borderWidth = 1
       ordersummaryView.layer.borderColor = UIColor.black.cgColor
        
        for item in arrData{
            //totalItems += item.qty
            //home
            totalItems += valuess

            totalAmount += item.rs
        }
        
        
        print(valuess)
        
        totalWithDelivery = totalAmount + 25.0
        //noOfItemsLbl.text = "\(totalItems)"
        //home //
        noOfItemsLbl.text = "\(valuess)"

        totalLbl.text = "\(totalAmount)"
        orderTotalLbl.text = "\(totalWithDelivery)"
        
    }
    
    @IBAction func conformBtnClick(_ sender: Any) {

        let alert = UIAlertController(title: "Confirm Order", message: "You surely want to place this Order", preferredStyle: .alert)
        
        let Yesaction = UIAlertAction(title: "YES", style: .default) { (action) in
            
            let orderPlacedVC = self.storyboard?.instantiateViewController(identifier: "opvc")as! OrderPlacdViewController
            orderPlacedVC.arrData = self.arrData
           
            var pastOrder = PastOrdersViewController()
            pastOrder.arrdata = self.arrData
            
            self.navigationController?.pushViewController(orderPlacedVC, animated: true)
        }
        
        let Noaction = UIAlertAction(title: "NO", style: .default) { (action) in
            
        }
        
        alert.addAction(Noaction)
        alert.addAction(Yesaction)
        
        present(alert, animated: true, completion: nil)
        
        
//MARK: Comment kelela code lagto ka?
//        let orderPlacedVC = self.storyboard?.instantiateViewController(identifier: "opvc")as! OrderPlacdViewController
//        orderPlacedVC.arrData = self.arrData
//        self.navigationController?.pushViewController(orderPlacedVC, animated: true)
        
    }
}


extension CheckOutViewController:UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.arrData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "checkoutcell", for: indexPath)as! CheckOutCollectionViewCell
        
        cell.namelbl.text = arrData[indexPath.row].name
        cell.quantitylbl.text = "Quantity : \(arrData[indexPath.row].qty)"
        cell.pricelbl.text = "Price : \(arrData[indexPath.row].rs)"
        cell.weightlbl.text = "Weight : \(arrData[indexPath.row].mrp)"
        cell.imagevie.image = arrData[indexPath.row].image
        
        
//        cell.backgroundColor = UIColor.white

//        cell.layer.borderColor = UIColor.lightGray.cgColor
//        cell.layer.borderWidth = 0.2
//        cell.layer.cornerRadius = 0.5
//        cell.clipsToBounds = true
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 8
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        CGSize(width: 140, height: 240)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        CGSize(width: 8, height: 240)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForFooterInSection section: Int) -> CGSize {
        CGSize(width: 8, height: 240)
    }
    
}
