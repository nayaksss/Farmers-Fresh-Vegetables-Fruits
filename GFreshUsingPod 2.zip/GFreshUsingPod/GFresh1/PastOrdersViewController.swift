//
//  OrderPlacedCollectionViewCell.swift
//  GFresh1
//
//  Created by Vinayak Balaji Tuptewar on 18/08/20.
//  Copyright © 2020 Vinayak Balaji Tuptewar. All rights reserved.
//
import UIKit

class PastOrdersViewController: UIViewController{
    
    @IBOutlet weak var tables: UITableView!
    
    @IBOutlet weak var collections: UICollectionView!
    
    
    var arrdata = [TempAddedArray]()
   
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tables.separatorStyle = .none
        
//        let r = TempAddedArray(name: "potato", qty: 3, rs: 30, mrp: 30, image: #imageLiteral(resourceName: "tomato"), totalItems: 2, totalAmount: 30)
//
//        arrdata = [r]
        
        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        
    }
    

   

}
extension PastOrdersViewController : UITableViewDataSource,UITableViewDelegate
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tables.dequeueReusableCell(withIdentifier: "pastcell", for: indexPath) as! PastOrderTableViewCell
        
//        cell.backgroundColor = UIColor.white
//        cell.layer.borderColor = UIColor.lightGray.cgColor
//        cell.layer.borderWidth = 0.2
//        cell.layer.cornerRadius = 0.5
//
//
//        cell.clipsToBounds = true
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 260
    }
    
}

extension PastOrdersViewController:UICollectionViewDelegateFlowLayout{
//MARK: UICollectionViewDataSource


//func numberOfSections(in collectionView: UICollectionView) -> Int {
//    return 1
//}
//
//    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
//        self.arrdata.count
//    }
//    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
//
//        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "pastcollectioncell", for: indexPath) as! PastOrderCollectionViewCell
//
//        cell.imgview.image = arrdata[indexPath.row].image
//
//        cell.namelbl.text = arrdata[indexPath.row].name
//
//        cell.pricelbl.text = String(arrdata[indexPath.row].mrp)
//
//        return cell
//
//    }
//
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 8
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        CGSize(width: 120, height: 150)
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        CGSize(width: 8, height: 150)
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForFooterInSection section: Int) -> CGSize {
        CGSize(width: 8, height: 150)
    }


}
    

