//
//  OrderPlacedCollectionViewCell.swift
//  GFresh1
//
//  Created by Vinayak Balaji Tuptewar on 18/08/20.
//  Copyright © 2020 Vinayak Balaji Tuptewar. All rights reserved.
//

import UIKit

class OfferCellViewController: UIViewController {

    
    @IBOutlet weak var offerTables: UITableView!
    
    var titleLable = ["Sunday Offer","Daily Offer","Wednesday Offer","Regular Customer Offer"]
    
    var detailLable = ["Get 25% off on vegetables* on purchase of Rs.75 or more","Get 10% off on vegetables* on purchase of Rs.200 or more","Get 25% off on vegetables* on purchase of Rs.100 or more","Get 5% off on vegetables* on purchase of Rs.50 or more"]
    override func viewDidLoad() {
        super.viewDidLoad()

       
       self.navigationItem.leftBarButtonItem?.title = "Offers"
        
        self.navigationController?.navigationBar.tintColor = .white
        offerTables.separatorStyle = .none
       //offerTables.tableFooterView = UIView()

    }
}
extension OfferCellViewController:UITableViewDelegate,UITableViewDataSource
{
        
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return titleLable.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        let cell = offerTables.dequeueReusableCell(withIdentifier: "offerCell", for: indexPath) as! OfferCellTableViewCell
        
        cell.titleOffer.text = titleLable[indexPath.row]
        cell.detailOffer.text = detailLable[indexPath.row]
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 180
    }
    
    
}
