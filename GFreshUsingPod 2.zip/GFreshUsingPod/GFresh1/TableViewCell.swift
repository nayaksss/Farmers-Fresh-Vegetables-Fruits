//
//  TableViewCell.swift
//  GFresh1
//
//  Created by Vinayak Balaji Tuptewar on 11/08/20.
//  Copyright © 2020 Vinayak Balaji Tuptewar. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {
   
    @IBOutlet weak var quantityView: UIView!
    @IBOutlet weak var constraintss: NSLayoutConstraint!
    
    @IBOutlet weak var imageview: UIImageView!
    @IBOutlet weak var namelbl: UILabel!
    @IBOutlet weak var quantity: UILabel!
    @IBOutlet weak var rslbl: UILabel!
    @IBOutlet weak var mrplbl: UILabel!
    @IBOutlet weak var addButton: UIButton!

    @IBOutlet weak var QuantityButton: UIButton!
    
    @IBOutlet weak var backViews: UIView!
    
    var tempcell : UITableViewCell?
    override func awakeFromNib() {
        super.awakeFromNib()
        //
//        self.backViews.layer.borderWidth = 1.0
//        self.backViews.layer.cornerRadius = 10.0
        
//        self.backViews.layer.borderColor = UIColor.clear.cgColor
        //        self.backViews.layer.masksToBounds = true
        
        self.backViews.layer.shadowOpacity = 0.4
        self.backViews.layer.shadowOffset = CGSize(width: 0, height: 4)
        self.backViews.layer.shadowRadius = 10.0
        self.backViews.layer.shadowColor = UIColor.lightGray.cgColor
        //        self.backViews.layer.masksToBounds = false
        
        
        //quantityView.isHidden = true
        addButton.layer.cornerRadius = 20
        //addButton.layer.borderWidth = 2
        
        
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    
    
    
    



    
}
