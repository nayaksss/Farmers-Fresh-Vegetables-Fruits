//
//  OrderPlacedCollectionViewCell.swift
//  GFresh1
//
//  Created by Vinayak Balaji Tuptewar on 18/08/20.
//  Copyright © 2020 Vinayak Balaji Tuptewar. All rights reserved.
//

import UIKit

protocol MyDataSendingDelegateProtocol {
    func sendDataToFirstViewController(myData: Int)
}



class CustomPopViewViewController: UIViewController {

    var quantityValue = 0
    var rs = 0
    var mrp = 0
    
    @IBOutlet weak var alerts: UIButton!
   
    var delegate: MyDataSendingDelegateProtocol? = nil
    
    var v = CarTableViewCell()
    var views = CartViewController()
    
    var cell = CarTableViewCell()
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

         
        
        self.view.backgroundColor = UIColor.clear.withAlphaComponent(0.8)
        
        self.showAnimate()
       
        
    }
    
    @IBAction func buttons(_ sender: UIButton) {
    
        if sender.tag == 1
        {
//            quantityValue = 1
//            rs = 30
//            mrp = 30
//
//           // v.qtylbl.text = "11kg"
            self.delegate?.sendDataToFirstViewController(myData: 1)
            
        }
        else if sender.tag == 2
        {
            //quantityValue = 250
//            rs = Int(7.5)
//            mrp = Int(7.5)
//
      self.delegate?.sendDataToFirstViewController(myData: 250)
        }
        else if sender.tag == 3
            
        {
//            quantityValue = 500
//            rs = 15
//            mrp = 15
//
 self.delegate?.sendDataToFirstViewController(myData: 500)
        }
        
        self.RemoveAnimate()
        //self.view.removeFromSuperview()
        
        //print(quantityValue,rs,mrp)
       
    }
    func showAnimate()
    {
        self.view.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
        
        self.view.alpha = 0.0
        
        UIView.animate(withDuration: 0.25,animations:  {
            self.view.alpha = 1.0
            self.view.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
        });
        
    }
    func RemoveAnimate()
    {
        UIView.animate(withDuration: 0.25, animations: {
            self.view.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
            self.view.alpha = 0.0
        }) { (finished : Bool) in
            if (finished)
            {
                self.view.removeFromSuperview()
            }
        }
    }
    
    @IBAction func closePopView(_ sender: UIButton) {
    RemoveAnimate()
    
    }
    
}
