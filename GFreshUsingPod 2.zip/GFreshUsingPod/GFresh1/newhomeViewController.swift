//
//  OrderPlacedCollectionViewCell.swift
//  GFresh1
//
//  Created by Vinayak Balaji Tuptewar on 18/08/20.
//  Copyright © 2020 Vinayak Balaji Tuptewar. All rights reserved.
//

import UIKit

class newhomeViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    @IBOutlet weak var tables: UITableView!
    
    let imageView = UIImageView()
    
    var headerviews : UIView?
    
    
    
    override func viewDidLoad() {
       
        
        headerviews = tables.tableHeaderView
        
        tables.tableHeaderView = nil
        
        tables.addSubview(headerviews!)
        
        
        tables.contentInset = UIEdgeInsets(top: 250, left: 0, bottom: 0, right: 0)
        
        tables.contentOffset = CGPoint(x: 0, y: -250)
        
        updateheader()
        
//        views.frame = CGRect(x: 0, y: 250, width: UIScreen.main.bounds.size.width, height: 50)
//
//        view.backgroundColor = .red
//
//        imageView.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: 250)
//
//        imageView.image = UIImage(named: "veg")
//        imageView.contentMode = .scaleAspectFill
//        imageView.clipsToBounds = true
//
//
//        view.addSubview(imageView)
//        view.addSubview(views)
        
        
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    func updateheader()
    {
        
        if tables.contentOffset.y < -250
        {
            headerviews!.frame.origin.y = tables.contentOffset.y
            
            headerviews!.frame.size.height = -tables.contentOffset.y
        }
        
    }
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
   
        updateheader()
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 50
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! newhomeTableViewCell
        cell.lbl.text = "sss"
        return cell
    }
}
