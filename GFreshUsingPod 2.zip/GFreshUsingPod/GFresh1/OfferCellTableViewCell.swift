//
//  OrderPlacedCollectionViewCell.swift
//  GFresh1
//
//  Created by Vinayak Balaji Tuptewar on 18/08/20.
//  Copyright © 2020 Vinayak Balaji Tuptewar. All rights reserved.
//

import UIKit

class OfferCellTableViewCell: UITableViewCell {

    @IBOutlet weak var titleOffer: UILabel!
    
    @IBOutlet weak var detailOffer: UILabel!
    
    @IBOutlet weak var backview: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        
//        self.backview.layer.borderWidth = 1
//        self.backview.layer.borderColor = UIColor.systemYellow.cgColor
//
//        //        self.CellBackView.layer.borderWidth = 1.0
//        self.backview.layer.cornerRadius = 10.0
//        self.clipsToBounds = true
//
//        self.backview.layer.borderColor = UIColor.clear.cgColor
//        //        self.CellBackView.layer.masksToBounds = true
//
//        self.backview.layer.shadowOpacity = 0.7
//        self.backview.layer.shadowOffset = CGSize(width: 0, height: 4)
//        self.backview.layer.shadowRadius = 4.0
//        self.backview.layer.shadowColor = UIColor.lightGray.cgColor
//        self.backview.layer.masksToBounds = false
        
        
        self.backview.layer.borderWidth = 1.0
        self.backview.layer.cornerRadius = 0

        self.backview.layer.borderColor = UIColor.clear.cgColor
        self.backview.layer.masksToBounds = true
        
        self.backview.layer.shadowOpacity = 0.7
        self.backview.layer.shadowOffset = CGSize(width: 0, height: 0)
        self.backview.layer.shadowRadius = 4.0
        self.backview.layer.shadowColor = UIColor.lightGray.cgColor
        self.backview.layer.masksToBounds = false
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
