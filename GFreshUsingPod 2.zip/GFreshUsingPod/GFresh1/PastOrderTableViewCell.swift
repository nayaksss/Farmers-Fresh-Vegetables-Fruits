//
//  OrderPlacedCollectionViewCell.swift
//  GFresh1
//
//  Created by Vinayak Balaji Tuptewar on 18/08/20.
//  Copyright © 2020 Vinayak Balaji Tuptewar. All rights reserved.
//

import UIKit

class PastOrderTableViewCell: UITableViewCell,UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {

    @IBOutlet weak var collections: UICollectionView!
    
    
    @IBOutlet weak var backview: UIView!
    @IBOutlet weak var contentViews: UIView!
    var imgArray = [UIImage]()
       var name = [String]()
       var price = [Int]()
    
    
    @IBOutlet weak var OrderOnView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        //Initialization code
        
        
        OrderOnView.layer.cornerRadius = 3.0
        
        self.collections.delegate = self
        self.collections.dataSource = self
        
        
        
        
        imgArray  = [#imageLiteral(resourceName: "tomato"),#imageLiteral(resourceName: "tomato"),#imageLiteral(resourceName: "tomato"),#imageLiteral(resourceName: "tomato"),#imageLiteral(resourceName: "tomato")]
           
            name = ["Tomato","Tomato","Tomato","Tomato","Tomato"]
           
            price = [9999,9444,4449,4449,449]
        
               self.backview.layer.borderWidth = 1.0
               self.backview.layer.cornerRadius = 0
       
               self.backview.layer.borderColor = UIColor.clear.cgColor
               self.backview.layer.masksToBounds = true
       
               self.backview.layer.shadowOpacity = 0.7
               self.backview.layer.shadowOffset = CGSize(width: 0, height: 0)
               self.backview.layer.shadowRadius = 4.0
               self.backview.layer.shadowColor = UIColor.lightGray.cgColor
               self.backview.layer.masksToBounds = false
        
        
       // newView.frame = CGRect(x: 0, y: 0, width: self.contentViews.bounds.width, height: self.contentViews.bounds.height)
        
//        newView.autoresizingMask = [.flexibleWidth,.flexibleHeight,.flexibleTopMargin,.flexibleBottomMargin,.flexibleLeftMargin,.flexibleRightMargin]
//        newView.layer.borderWidth = 0.7
//                newView.layer.cornerRadius = 5
//
//
//        newView.layer.borderColor = UIColor.black.cgColor
//                newView.layer.masksToBounds = true
//
//                newView.layer.shadowOpacity = 5.0
//        newView.layer.shadowOffset = CGSize(width: 0, height: 2.0)
//                newView.layer.shadowRadius = 2.0
//                newView.layer.shadowColor = UIColor.lightGray.cgColor
//            newView.layer.masksToBounds = false
//
//
//        self.contentViews.addSubview(newView)
//
        
        
//        self.contentViews.layer.borderWidth = 1.0
//                self.contentViews.layer.cornerRadius = 0
//
//
//         self.contentViews.layer.borderColor = UIColor.clear.cgColor
//                self.contentViews.layer.masksToBounds = true
//
//        self.contentViews.layer.shadowOpacity = 0.7
//        self.contentViews.layer.shadowOffset = CGSize(width: 0, height: 0)
//                self.contentViews.layer.shadowRadius = 4.0
//                self.contentViews.layer.shadowColor = UIColor.lightGray.cgColor
//                self.contentViews.layer.masksToBounds = false

//

        
        
    }

    override func layoutSubviews() {
        super.layoutSubviews()

        
//        backview.frame = backview.frame.inset(by: UIEdgeInsets(top: 0, left: 0, bottom: 10, right: 0))
        
//        contentViews.frame = contentView.frame.inset(by: UIEdgeInsets(top: 0, left: 0, bottom: 10, right: 0))
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    func numberOfSections(in collectionView: UICollectionView) -> Int {
    return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 3
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collections.dequeueReusableCell(withReuseIdentifier: "pastcollectioncell", for: indexPath) as! PastOrderCollectionViewCell
        
        cell.imgview.image = imgArray[0]
        cell.namelbl.text = name[indexPath.row]
        cell.pricelbl.text = "Price :"+String(price[indexPath.row])
        
        cell.backgroundColor = UIColor.white

        cell.layer.borderColor = UIColor.lightGray.cgColor
        cell.layer.borderWidth = 0.2
        cell.layer.cornerRadius = 0.5
        cell.clipsToBounds = true
//
//        cell.layer.borderColor = UIColor.clear.cgColor
//        cell.layer.masksToBounds = true
//
//        cell.layer.shadowOpacity = 0.7
//
//        cell.layer.shadowOffset = CGSize(width: 0, height: 0)
//
//        cell.layer.shadowRadius = 4.0
//
//        cell.layer.shadowColor = UIColor.lightGray.cgColor
//
//        cell.layer.masksToBounds = false
        
        return cell
    }
    
   func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 2
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        CGSize(width: 80, height: 120)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        CGSize(width: 8, height: 220)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForFooterInSection section: Int) -> CGSize {
        CGSize(width: 8, height: 220)
    }
    
    
}
extension UITableViewCell{
    

    
}
