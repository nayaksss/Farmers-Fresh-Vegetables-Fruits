//
//  OrderPlacedCollectionViewCell.swift
//  GFresh1
//
//  Created by Vinayak Balaji Tuptewar on 18/08/20.
//  Copyright © 2020 Vinayak Balaji Tuptewar. All rights reserved.
//

import UIKit

class PastOrderCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imgview: UIImageView!
    @IBOutlet weak var namelbl: UILabel!
    @IBOutlet weak var pricelbl: UILabel!
    
    @IBOutlet weak var backViews: UIView!
    
    
    override func layoutSubviews() {
        self.backViews.layer.shadowOpacity = 0.4
        self.backViews.layer.shadowOffset = CGSize(width: 0, height: 0)
        self.backViews.layer.shadowRadius = 4.0
        self.backViews.layer.shadowColor = UIColor.lightGray.cgColor
    }
    
}
