//
//  OrderPlacedCollectionViewCell.swift
//  GFresh1
//
//  Created by Vinayak Balaji Tuptewar on 18/08/20.
//  Copyright © 2020 Vinayak Balaji Tuptewar. All rights reserved.
//

import UIKit

class CustomHomePopViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

         self.view.backgroundColor = UIColor.clear.withAlphaComponent(0)
        self.showAnimate()
        // Do any additional setup after loading the view.
    }
    

    
    func showAnimate()
    {
        self.view.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
        
        self.view.alpha = 0.0
        
        UIView.animate(withDuration: 0.25,animations:  {
            self.view.alpha = 1.0
            self.view.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
        });
        
    }
    
    @IBAction func buttons(_ sender: UIButton) {
        
        RemoveAnimate()
        
    }
    
    func RemoveAnimate()
       {
           UIView.animate(withDuration: 0.25, animations: {
               self.view.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
               self.view.alpha = 0.0
           }) { (finished : Bool) in
               if (finished)
               {
                   self.view.removeFromSuperview()
               }
           }
       }
       
    
}
