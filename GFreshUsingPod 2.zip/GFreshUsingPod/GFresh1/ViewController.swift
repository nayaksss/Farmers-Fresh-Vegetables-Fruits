//
//  OrderPlacedCollectionViewCell.swift
//  GFresh1
//
//  Created by Vinayak Balaji Tuptewar on 18/08/20.
//  Copyright © 2020 Vinayak Balaji Tuptewar. All rights reserved.
//

import UIKit
import DropDown

class ViewController: UIViewController {
    
    var sideBarView:UIView!
    var tableview:UITableView!
    var isEnableSideBar = false
    var arrData = ["Home", "Past Orders", "Your Offers","Track Your Orders","Notifications","Customer Service","FAQs"]
    var arrImages = [#imageLiteral(resourceName: "nhome"),#imageLiteral(resourceName: "ncart"),#imageLiteral(resourceName: "nyour"),#imageLiteral(resourceName: "nmap"),#imageLiteral(resourceName: "nnotication"),#imageLiteral(resourceName: "ncustomer"),#imageLiteral(resourceName: "nfaq")]
    var imageV:UIImageView!
    var lbl:UILabel!
    var titleLbl:UILabel!
    var detailTitleLbl:UILabel!
    var extraView:UIView!
    var arrVeG = [["potato","Tomato","onion","cabbage","carrot"],[1,1,1,1,1],[30.0,30.0,30.0,30.0,30.0],[#imageLiteral(resourceName: "potato"),#imageLiteral(resourceName: "tomato"),#imageLiteral(resourceName: "onion"),#imageLiteral(resourceName: "cabbage"),#imageLiteral(resourceName: "carrot")]]
    var arrLeafyVeG = [["Spinach","Methi","Mint","Coriander","Coriander"],[1,1,1,1,1],[10.0,10.0,10.0,10.0,10.0],[#imageLiteral(resourceName: "cabbage"),#imageLiteral(resourceName: "carrot"),#imageLiteral(resourceName: "potato"),#imageLiteral(resourceName: "tomato"),#imageLiteral(resourceName: "onion")]]
    var arrExotic = [["brocolli","zucchini","baby Corn","cabbage red","cherry tomato"],[1,1,1,1,1],[30.0,30.0,30.0,30.0,30.0],[#imageLiteral(resourceName: "onion"),#imageLiteral(resourceName: "cabbage"),#imageLiteral(resourceName: "carrot"),#imageLiteral(resourceName: "potato"),#imageLiteral(resourceName: "tomato")]]
    
    @IBOutlet weak var vegetables: UIButton!
    @IBOutlet weak var leafyVeg: UIButton!
    @IBOutlet weak var exotic: UIButton!
    var tag = 1
    
    @IBOutlet weak var vegetables1: UIButton!
    @IBOutlet weak var leafyVeg1: UIButton!
    @IBOutlet weak var exotic1: UIButton!
    
    
    var kTableHeaderHeight:CGFloat = 300.0
    @IBOutlet weak var strechyTableView: UITableView!
    var headerView: UIView!
    @IBOutlet weak var stackviews: UIStackView!
    
    var tapGest = UITapGestureRecognizer()
    var swipeToLeft = UISwipeGestureRecognizer()
    var swipeToRight = UISwipeGestureRecognizer()
    var tempView = UIView()
    
    var totalItems:Int = 0
    var totalAmount:Double = 0.0
    @IBOutlet weak var bottomView: UIView!
    @IBOutlet weak var itemslbl: UILabel!
    @IBOutlet weak var amountlbl: UILabel!
    var topBarAndNavigationBArHeight = CGFloat()
    
    var tempSelectedArrays = [TempAddedArray]()

    @IBOutlet weak var btnsViewAboveImageV: UIView!
    @IBOutlet weak var btnsViewBelowImageV: UIView!
    
    let dropDown = DropDown()
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        bottomView.layer.cornerRadius = 7.0
        load_SideBarView_TableView_Functionality()
        loadGestureFunctionality()
        //load_Functionality()
        load_Buttons_Functionality()
        self.strechyTableView.separatorStyle = .none
        self.strechyTableView.bounces = false
        
    }
    
    
    @IBAction func categoryBtn(_ sender: UIButton) {
        if sender.tag == 1 || sender.tag == 4{
            tag = 1
        }else if sender.tag == 2 || sender.tag == 5{
            tag = 2
        }else if sender.tag == 3 || sender.tag == 6{
            tag = 3
        }
        print(sender.tag)
        self.strechyTableView.reloadData()
    }

    
    @IBAction func vegetablesClick(_ sender: UIButton){
        tag = 1
        self.strechyTableView.reloadData()
    }
    @IBAction func leafyVegClick(_ sender: UIButton) {
        tag = 2
        self.strechyTableView.reloadData()
    }
    @IBAction func exoticClick(_ sender: UIButton) {
        tag = 3
        self.strechyTableView.reloadData()
    }
    
    
    @IBAction func addBtnClick(_ sender: UIButton) {
        if tag == 1{
            totalItems += self.arrVeG[1][sender.tag]as! Int
            totalAmount += self.arrVeG[2][sender.tag]as! Double
            itemslbl.text = "\(totalItems) ITEMS"
            amountlbl.text = "Amount \(totalAmount).0"
            
            var tempAddedArray = TempAddedArray(name: self.arrVeG[0][sender.tag]as! String,
                qty: arrVeG[1][sender.tag]as! Int,
                rs: arrVeG[2][sender.tag]as! Double,
                mrp: arrVeG[2][sender.tag]as! Double,
                image: arrVeG[3][sender.tag] as! UIImage,
                totalItems: totalItems,
                totalAmount: totalAmount)
            tempSelectedArrays.append(tempAddedArray)
            
        }else if tag == 2{
            totalItems += self.arrLeafyVeG[1][sender.tag]as! Int
            totalAmount += self.arrLeafyVeG[2][sender.tag]as! Double
            itemslbl.text = "\(totalItems) ITEMS"
            amountlbl.text = "Amount \(totalAmount).0"
            
            var tempAddedArray = TempAddedArray(name: self.arrLeafyVeG[0][sender.tag]as! String,
                qty: arrLeafyVeG[1][sender.tag]as! Int,
                rs: arrLeafyVeG[2][sender.tag]as! Double,
                mrp: arrLeafyVeG[2][sender.tag]as! Double,
                image: arrLeafyVeG[3][sender.tag] as! UIImage,
                totalItems: totalItems,
                totalAmount: totalAmount)
            tempSelectedArrays.append(tempAddedArray)
            
            
        }else if tag == 3{
            totalItems += self.arrExotic[1][sender.tag]as! Int
            totalAmount += self.arrExotic[2][sender.tag]as! Double
            itemslbl.text = "\(totalItems) ITEMS"
            amountlbl.text = "Amount \(totalAmount).0"
            
            let tempAddedArray = TempAddedArray(name: self.arrExotic[0][sender.tag]as! String,
                qty: arrExotic[1][sender.tag]as! Int,
                rs: arrExotic[2][sender.tag]as! Double,
                mrp: arrExotic[2][sender.tag]as! Double,
                image: arrExotic[3][sender.tag] as! UIImage,
                totalItems: totalItems,
                totalAmount: totalAmount)
            tempSelectedArrays.append(tempAddedArray)
            
        }
    }
    
    
    @IBAction func menubtn(_ sender: UIButton) {
        if isEnableSideBar{
            self.view.addGestureRecognizer(swipeToRight)
            self.view.removeGestureRecognizer(swipeToLeft)
            UIView.animate(withDuration: 0.2) {
                self.sideBarView.frame = CGRect(x: 0, y: self.topBarAndNavigationBArHeight, width: 0, height: self.view.bounds.height - self.topBarAndNavigationBArHeight)
                self.tableview.frame = CGRect(x: 0, y: 150, width: 0, height: self.sideBarView.bounds.height - 150)
                self.titleLbl.frame = CGRect(x: 20, y: 55, width: 0, height: 30)
                self.detailTitleLbl.frame = CGRect(x:20, y:85, width:0, height:55)
            }
            self.tempView.isHidden = true
//            self.tempView.layer.opacity = 1
            isEnableSideBar = false
        }else{
            self.view.addGestureRecognizer(swipeToLeft)
            self.view
    .removeGestureRecognizer(swipeToRight)
            UIView.animate(withDuration: 0.1) {
                self.sideBarView.frame = CGRect(x: 0, y: self.topBarAndNavigationBArHeight, width: self.view.bounds.width/1.3, height: self.view.bounds.height - self.topBarAndNavigationBArHeight)
                self.tableview.frame = CGRect(x: 0, y: 150, width: self.sideBarView.bounds.width, height: self.sideBarView.bounds.height - 150)
                self.titleLbl.frame = CGRect(x:20, y:55, width:self.sideBarView.bounds.width - 40, height:30)
                self.detailTitleLbl.frame = CGRect(x:20, y:85, width:self.sideBarView.bounds.width - 40, height:55)
                
            }
            self.tempView.isHidden = false
//            self.tempView.layer.opacity = 0.5
            isEnableSideBar = true
        }
    }
    
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        //updateHeaderView()
        
        var y = -scrollView.contentOffset.y
        
        if y < -250{
            btnsViewAboveImageV.isHidden = false
            btnsViewBelowImageV.isHidden = true
        }else{
            btnsViewAboveImageV.isHidden = true
            btnsViewBelowImageV.isHidden = false
        }
    }
    
    func updateHeaderView() {
        var headerRect = CGRect(x: 0, y: -kTableHeaderHeight, width: strechyTableView.bounds.width, height: kTableHeaderHeight)
        if strechyTableView.contentOffset.y < -kTableHeaderHeight {
            headerRect.origin.y = strechyTableView.contentOffset.y
            headerRect.size.height = -strechyTableView.contentOffset.y
        }
        headerView.frame = headerRect
    }
    
    func load_SideBarView_TableView_Functionality(){
        let topBarHeight = UIApplication.shared.statusBarFrame.size.height + (self.navigationController?.navigationBar.frame.height ?? 0.0)
        topBarAndNavigationBArHeight = topBarHeight
        
        sideBarView = UIView(frame: CGRect(x: 0, y: topBarAndNavigationBArHeight, width: 0, height: self.view.bounds.height - topBarAndNavigationBArHeight))
        sideBarView.backgroundColor = UIColor.init(red: 178/255, green: 80/255, blue: 79/255, alpha: 1)
        
        tableview = UITableView(frame: CGRect(x: 0, y: 150, width: 0, height: self.sideBarView.bounds.height - 150), style: .plain)
        tableview.backgroundColor = .white
        
        titleLbl = UILabel(frame: CGRect(x: 20, y: 55, width: 0, height: 30))
        titleLbl.backgroundColor = UIColor.init(red: 178/255, green: 80/255, blue: 79/255, alpha: 1)
        titleLbl.text = "GAUTAM DHANGARWAL"
        titleLbl.font = UIFont.systemFont(ofSize: 22.0)
        titleLbl.textColor = UIColor.white
        
        detailTitleLbl = UILabel(frame: CGRect(x: 20, y:85, width: 0, height: 55))
        detailTitleLbl.backgroundColor = UIColor.init(red: 178/255, green: 80/255, blue: 79/255, alpha: 1)
        detailTitleLbl.numberOfLines = 0
        detailTitleLbl.text = "25 Building 13,Opp.Bosco center, Ganpati road,Nashik."
        detailTitleLbl.textColor = UIColor.white
        
        self.view.addSubview(sideBarView)
        self.sideBarView.addSubview(titleLbl)
        self.sideBarView.addSubview(detailTitleLbl)
        self.sideBarView.addSubview(tableview)
        
        tableview.register(UITableViewCell.self, forCellReuseIdentifier: "mycell")
        tableview.delegate=self
        tableview.dataSource=self
        tableview.bounces = false
        
        tableview.tag = 1
        strechyTableView.tag = 2
    }
    
    func loadGestureFunctionality(){
        swipeToLeft = UISwipeGestureRecognizer(target: self, action: #selector(swipedToLeft))
        swipeToLeft.direction = .left
        
        swipeToRight = UISwipeGestureRecognizer(target: self, action: #selector(swipedToRightSide))
        swipeToRight.direction = .right
        self.view.addGestureRecognizer(swipeToRight)
        
        tapGest = UITapGestureRecognizer(target: self, action: #selector(dismissSideBarView))
        
        tempView = UIView(frame: CGRect(x: self.view.bounds.width/1.5, y: 0, width: self.view.bounds.width-self.view.bounds.width/1.5, height: self.view.bounds.height))
        self.tempView.addGestureRecognizer(tapGest)
        self.view.addSubview(tempView)
        self.tempView.isHidden = true
    }
    
    func load_Functionality(){
        strechyTableView.rowHeight = UITableView.automaticDimension
        headerView = strechyTableView.tableHeaderView
        strechyTableView.tableHeaderView = nil
        strechyTableView.addSubview(headerView)
        strechyTableView.contentInset = UIEdgeInsets(top: kTableHeaderHeight, left: 0, bottom: 0, right: 0)
        strechyTableView.contentOffset = CGPoint(x: 0, y: -kTableHeaderHeight)
        updateHeaderView()
        
        bottomView.layer.cornerRadius = bottomView.bounds.height/6
    }
    
    
    func load_Buttons_Functionality(){
        btnsViewAboveImageV.isHidden = true
        
        vegetables.tag = 1
        leafyVeg.tag = 2
        exotic.tag = 3
        
        vegetables1.tag = 4
        leafyVeg1.tag = 5
        exotic1.tag = 6
    }
    
    
    @IBAction func viewCartBtn(_ sender: UIButton) {
        print("View Cart Button Clicked")
        let cartVC = self.storyboard?.instantiateViewController(withIdentifier: "cvc")as!CartViewController
        cartVC.arrData = tempSelectedArrays
        self.navigationController?.pushViewController(cartVC, animated: true)
        
    }
    
}



//MARK: Table View Methods
extension ViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView.tag == 1{
            return arrData.count
        }else{
            if tag == 1{
                return arrVeG[0].count
            }else if tag == 2{
                return arrLeafyVeG[0].count
            }else if tag == 3{
                return arrExotic[0].count
            }
        }
        return 0
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if tableView.tag == 1{
            let cell = tableview.dequeueReusableCell(withIdentifier: "mycell", for: indexPath)
            
            imageV = UIImageView(frame: CGRect(x: 8, y: 8, width: cell.bounds.height-16, height: cell.bounds.height-16))
            imageV.contentMode = .scaleAspectFill
            imageV.image = self.arrImages[indexPath.row]
            //       imageV.backgroundColor = .cyan
            cell.addSubview(imageV)
            
            lbl = UILabel(frame: CGRect(x: imageV.bounds.width+24, y: 8, width: cell.bounds.width-(imageV.bounds.width+24), height: cell.bounds.height-16))
            //        lbl.backgroundColor = .yellow
            lbl.text = arrData[indexPath.row]
            lbl.font = UIFont.init(name: "Avenir", size: 12)
            lbl.font = UIFont.preferredFont(forTextStyle: .title3)
            //UIFont.systemFont(ofSize: 21)
            
            cell.addSubview(lbl)
            
            tableview.separatorStyle = .none
            cell.backgroundColor = .white
            
            return cell
        }else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TableViewCell
            
            if tag == 1{
                cell.namelbl.text = arrVeG[0][indexPath.row] as! String
                cell.quantity.text = "\(arrVeG[1][indexPath.row])kg"
                cell.rslbl.text = "Rs.\(arrVeG[2][indexPath.row])"
                cell.mrplbl.text = "MRP     \(arrVeG[2][indexPath.row]).0"
                cell.imageview.image = arrVeG[3][indexPath.row] as! UIImage
                cell.addButton.tag = indexPath.row
                
                cell.QuantityButton.tag = indexPath.row
                cell.QuantityButton.addTarget(self, action: #selector(quantityButton(_:)), for: .touchUpInside)
                
            }else if tag == 2{
                cell.namelbl.text = arrLeafyVeG[0][indexPath.row] as! String
                cell.quantity.text = "\(arrLeafyVeG[1][indexPath.row])Bunch"
                cell.rslbl.text = "Rs.\(arrLeafyVeG[2][indexPath.row])"
                cell.mrplbl.text = "MRP     \(arrLeafyVeG[2][indexPath.row]).0"
                cell.imageview.image = arrLeafyVeG[3][indexPath.row] as! UIImage
                cell.addButton.tag = indexPath.row
                
                cell.QuantityButton.tag = indexPath.row
                cell.QuantityButton.addTarget(self, action: #selector(quantityButton(_:)), for: .touchUpInside)
                
            }else if tag == 3{
                cell.namelbl.text = arrExotic[0][indexPath.row] as! String
                cell.quantity.text = "\(arrExotic[1][indexPath.row])kg"
                cell.rslbl.text = "Rs.\(arrExotic[2][indexPath.row])"
                cell.mrplbl.text = "MRP     \(arrExotic[2][indexPath.row]).0"
                cell.imageview.image = arrExotic[3][indexPath.row] as! UIImage
                cell.addButton.tag = indexPath.row
                
                cell.QuantityButton.tag = indexPath.row
                cell.QuantityButton.addTarget(self, action: #selector(quantityButton(_:)), for: .touchUpInside)
            }
            return cell
 
           cell.indentationLevel = 2;
        }
        return UITableViewCell()
    }

    @objc func quantityButton(_ sender : UIButton){
        
        self.dropDown.anchorView = sender // The view to which the drop down will appear on
        self.dropDown.width = 70
        self.dropDown.bottomOffset = CGPoint(x: 0, y: sender.bounds.height) //  Top of drop down will be below the anchorView

        self.dropDown.dataSource = ["250 gm", "500 gm", "1 kg"] // Static array you need to change as per your requirement
        self.dropDown.selectionAction = { [unowned self] (index, item) in
            print(item) // **NOTE: I AM JUST PRINTING DROPDOWN SELECTED VALUE HERE, YOU NEED TO GET `UICollectionViewCell` HERE YOU NEED TO SET VALUE INSIDE CELL LABEL OR YOU CAN SET SELECTED DROPDOWN VALUE IN YOUR MODEL AND RELOAD COLLECTIONVIEW**
        self.strechyTableView.reloadData()
        
        }
        self.dropDown.show()
        
        
        
        

//        let cell = tableview.dequeueReusableCell(withIdentifier: "cell") as! TableViewCell
//
//        let x =  cell.QuantityButton.frame.midX
//        let y = cell.QuantityButton.frame.midY
//
//
//
//        let pop = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(identifier: "popUps") as! CustomHomePopViewController
//
//        self.addChild(pop)
//
//       pop.view.frame  = self.view.frame
//
//        self.view.addSubview(pop.view)
//
//        pop.didMove(toParent: self)
    
    }
    
    
    
        
        
        //dismiss(animated: true, completion: nil)
        
        
//        let cell = strechyTableView.dequeueReusableCell(withIdentifier: "cell") as! TableViewCell
//
//        let popController = PopoverController(items: setupPopItem(), fromView: cell.QuantityButton, direction: .up, reverseHorizontalCoordinates: true, style: PopoverStyle.normal, initialIndex: 1) {
//                   print("Yeah Done !!")
//               }
//               popover(popController)
//
//        print("quantity button \(sender.tag)")
    }
    
//    private func setupPopItem() -> [PopoverItem]{
//        let google = PopoverItem(title: "Google", titleColor: .clear, image: #imageLiteral(resourceName: "carrot")) {
//            debugPrint($0.title) // code here for click event
//        }
//        let fb = PopoverItem(title: "FB", titleColor: .clear, image: #imageLiteral(resourceName: "potato")){
//            debugPrint($0.title) // code here for click event
//        }
//        let twitter = PopoverItem(title: "Twitter", titleColor: .clear, image: #imageLiteral(resourceName: "veg")){
//            debugPrint($0.title) // code here for click event
//        }
//        let linkedin = PopoverItem(title: "Linkedin", titleColor: .clear, image: #imageLiteral(resourceName: "onion")){
//            debugPrint($0.title) // code here for click event
//        }
//        return [google, fb, twitter, linkedin]
//    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if tableView.tag == 1{
            return 200
        }else{
            return 120
        }
        
    }
    
//    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
//        return 50
//    }
    
//    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
//        return UIView(frame: CGRect(x: 0, y: 0, width: 300, height: 60))
//    }
    



//MARK: Gestures(tap,swipeRight,swipeLeft) Methods
extension ViewController: UITableViewDelegate {
    @objc func dismissSideBarView(){
        print("tap gesture ")
        self.view.removeGestureRecognizer(swipeToLeft)
        self.view.addGestureRecognizer(swipeToRight)
        UIView.animate(withDuration: 0.2) {
            self.sideBarView.frame.size.width = 0
            self.tableview.frame.size.width = 0
            self.titleLbl.frame.size.width = 0
            self.detailTitleLbl.frame.size.width = 0        }
        self.tempView.isHidden = true
        isEnableSideBar = false
    }
    
    
    @objc func swipedToLeft(){
        print("swiped to left")
        self.view.removeGestureRecognizer(swipeToLeft)
        self.view.addGestureRecognizer(swipeToRight)
        UIView.animate(withDuration: 0.2) {
            self.sideBarView.frame.size.width = 0
            self.tableview.frame.size.width = 0
            self.titleLbl.frame.size.width = 0
            self.detailTitleLbl.frame.size.width = 0
        }
        self.tempView.isHidden = true
        isEnableSideBar = false
    }
    

    @objc func swipedToRightSide(){
        print("swiped to right")
        self.view.addGestureRecognizer(swipeToLeft)
        self.view.removeGestureRecognizer(swipeToRight)
        UIView.animate(withDuration: 0.1) {
            self.sideBarView.frame.size.width = self.view.bounds.width/1.3
            self.tableview.frame.size.width = self.sideBarView.bounds.width
            self.titleLbl.frame.size.width = self.sideBarView.bounds.width - 40
            self.detailTitleLbl.frame.size.width = self.sideBarView.bounds.width - 40
        }
        self.tempView.isHidden = false
        isEnableSideBar = true
    }
    
}
