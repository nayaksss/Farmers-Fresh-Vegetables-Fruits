//
//  Models.swift
//  GFresh1
//
//  Created by Vinayak Balaji Tuptewar on 17/08/20.
//  Copyright © 2020 Vinayak Balaji Tuptewar. All rights reserved.
//

import UIKit

class TempAddedArray {
    var name:String
    var qty:Int
    var rs:Double
    var mrp:Double
    var image:UIImage
    var totalItems:Int
    var totalAmount:Double

    init(name:String,qty:Int,rs:Double,mrp:Double,image:UIImage,totalItems:Int,totalAmount:Double) {
        self.name = name
        self.qty = qty
        self.rs =  rs
        self.mrp = mrp
        self.image = image
        self.totalItems = totalItems
        self.totalAmount = totalAmount
    }
}
