//
//  CartViewController.swift
//  GFresh1
//
//  Created by Vinayak Balaji Tuptewar on 17/08/20.
//  Copyright © 2020 Vinayak Balaji Tuptewar. All rights reserved.
//chnages


import UIKit

class CartViewController: UIViewController,MyDataSendingDelegateProtocol{

    var arrData = [TempAddedArray]()
    @IBOutlet weak var tableView: UITableView!
    
   
    @IBOutlet weak var offerView: UIView!
    
    var values  = 1
    
    var tagValue : Int?
    
    
    @IBOutlet weak var Outers: UIView!
    
    @IBOutlet weak var outerbutton: UIButton!
    @IBAction func applyOfferBtnClick(_ sender: UIButton) {
        
        var offer = storyboard?.instantiateViewController(withIdentifier: "offer") as! OfferCellViewController
        
        self.navigationController?.pushViewController(offer, animated: true)
        
    }
    @IBAction func checkOutBtnClick(_ sender: Any) {
        let checkOutVC = self.storyboard?.instantiateViewController(withIdentifier: "checkoutvc")as! CheckOutViewController
        checkOutVC.arrData = arrData
       
       
        checkOutVC.valuess = values
       
        
        self.navigationController?.pushViewController(checkOutVC, animated: true)
    }

   
    override func viewDidLoad() {
        super.viewDidLoad()
        
        Outers.isHidden = true
        //self.navigationItem.leftBarButtonItem?.title = "Cart"
        
       
        self.navigationController?.navigationItem.leftBarButtonItem?.title = "cart"
        
        offerView.layer.cornerRadius = 5.0
        //self.tabBarController?.tabBar.isHidden = true
        
        //shows()
        
        tableView.separatorStyle = .none
        self.navigationController?.navigationBar.tintColor = .white
        }
    @objc func addValue(_ sender: UIButton)
    {
        
        self.arrData[sender.tag].qty += 1
        tableView.reloadData()
        //print(sender.tag)
    }
    @objc func minusValue(_ sender: UIButton)
    {
        
        self.arrData[sender.tag].qty -= 1
        
      if  self.arrData[sender.tag].qty == 0
        {
            self.arrData.remove(at: sender.tag)
        }

        
        //values -= 1
        tableView.reloadData()
        
        
        
        
       // print(values)
        //print("minus click")
        //print(sender.tag)

    }
    
    @IBAction func outerbuttons(_ sender: UIButton) {
        
    }
}


extension CartViewController:UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrData.count
       }
       
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cartcell", for: indexPath) as! CarTableViewCell
        
        cell.namelbl.text = arrData[indexPath.row].name
        cell.qtylbl.text = "\(arrData[indexPath.row].qty) Kg"
        cell.rslbl.text = "Rs.   \(arrData[indexPath.row].rs)"
        cell.mrplbl.text = "MRP   \(arrData[indexPath.row].mrp)"
        cell.imagev.image = arrData[indexPath.row].image
        
        cell.qtyBtn.tag = indexPath.row
        
        cell.qtyBtn.addTarget(self,action : #selector(quantityButton(_:)),for: .touchUpInside)
        
        cell.plusbtn.tag = indexPath.row
        cell.minusbtn.tag = indexPath.row
        
        cell.plusbtn.addTarget(self, action: #selector(addValue(_:)), for: .touchUpInside)
        
        cell.minusbtn.addTarget(self, action: #selector(minusValue(_:)), for: .touchUpInside)
        
        
        
        cell.minuspluslbl?.text = "\(arrData[indexPath.row].qty)"
        
        
        
        
        return cell
    }
    
    func sendDataToFirstViewController(myData: Int) {
        
        arrData[tagValue!].qty = myData
        
        
        DispatchQueue.main.async {
            
            self.tableView.reloadData()

        }
        
       // print(lbls)

    }
    
    
    @objc func quantityButton(_ sender : UIButton)
      {

            tagValue = sender.tag
            let pop = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(identifier: "popUp") as! CustomPopViewViewController

            self.addChild(pop)

            pop.view.frame = self.view.frame

            self.view.addSubview(pop.view)

            pop.delegate = self
        
            pop.didMove(toParent: self)
            
    }

                   
    
            
    
    
        //present(views, animated: true, completion: nil)
//        let optionMenu = UIAlertController(title: nil, message: "", preferredStyle: .alert)
//
//
//        // 2
//        let deleteAction = UIAlertAction(title: "Delete", style: .default)
//        let saveAction = UIAlertAction(title: "Save", style: .default)
//
//        // 3
//        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel)
//
//        // 4
//        optionMenu.addAction(deleteAction)
//        optionMenu.addAction(saveAction)
//        optionMenu.addAction(cancelAction)
//
//        // 5
//        self.present(optionMenu, animated: true, completion: nil)
    
    
       func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
}
    
}

