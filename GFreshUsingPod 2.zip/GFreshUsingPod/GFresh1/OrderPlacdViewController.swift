//
//  OrderPlacdViewController.swift
//  GFresh1
//
//  Created by Vinayak Balaji Tuptewar on 18/08/20.
//  Copyright © 2020 Vinayak Balaji Tuptewar. All rights reserved.


import UIKit

class OrderPlacdViewController: UIViewController {
    @IBOutlet weak var collectionView: UICollectionView!
    var arrData = [TempAddedArray]()
    @IBOutlet weak var noOfItemsLbl: UILabel!
    @IBOutlet weak var totalLbl: UILabel!
    @IBOutlet weak var orderTotalLbl: UILabel!
    
    @IBOutlet weak var continueButton: UIButton!
    
    @IBOutlet weak var orderSummary: UIView!
    var totalItems = Int()
    var totalAmount = Double()
    var totalWithDelivery = Double()
    
    @IBOutlet weak var orderPlaceView: UIView!
    @IBOutlet weak var scrollViews: UIScrollView!
    @IBOutlet weak var viewBelowScrollV: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        scrollViews.bounces = false
//        let leftItem = UIBarButtonItem(title: "GFresh",
//                                       style: UIBarButtonItem.Style.plain,
//                                       target: nil,
//                                       action: nil)
//        leftItem.isEnabled = false
//
//        self.navigationItem.leftBarButtonItem = leftItem
        
       //self.navigationItem.leftBarButtonItem?.title = "GFresh"
        continueButton.layer.cornerRadius = 15
    
        self.viewBelowScrollV.layer.shadowOpacity = 0.4
        self.viewBelowScrollV.layer.shadowOffset = CGSize(width: 0, height: 3)
        self.viewBelowScrollV.layer.shadowRadius = 6.0
        self.viewBelowScrollV.layer.shadowColor = UIColor.lightGray.cgColor
        
        
        self.navigationController?.navigationBar.tintColor = .white
        orderSummary.layer.borderWidth = 1
        orderSummary.layer.borderColor = UIColor.black.cgColor
        
        for item in arrData{
            totalItems += item.qty
            totalAmount += item.rs
        }
        totalWithDelivery = totalAmount + 25.0
        noOfItemsLbl.text = "\(totalItems)"
        totalLbl.text = "\(totalAmount)"
        orderTotalLbl.text = "\(totalWithDelivery)"
    }
    @IBAction func conformBtnClick(_ sender: Any) {
        
        var home = storyboard?.instantiateViewController(withIdentifier: "Home") as! ViewController
        self.navigationController?.pushViewController(home, animated: true)
        
    }
}


extension OrderPlacdViewController:UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.arrData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "orderplacedcell", for: indexPath)as! OrderPlacedCollectionViewCell
        
        cell.namelbl.text = arrData[indexPath.row].name
        cell.quantitylbl.text = "Quantity : \(arrData[indexPath.row].qty)"
        cell.pricelbl.text = "Price : \(arrData[indexPath.row].rs)"
        cell.weightlbl.text = "Weight : \(arrData[indexPath.row].mrp)"
        cell.imagevie.image = arrData[indexPath.row].image
        
        cell.backgroundColor = UIColor.white

        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 8
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        CGSize(width: 140, height: 240)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        CGSize(width: 8, height: 240)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForFooterInSection section: Int) -> CGSize {
        CGSize(width: 8, height: 240)
    }
    
}
